please load Avionics_lua_final_v4 lua onto the cube before starting the script
make sure the flap_position txt was not empty
if data recording wants to be kept: for cmd rename the txt file after quit, for data logging rename the file in sd card via mission planner(where also quit was required)
if the script wasn't runnable(because no cube with us during this script's development), please use the wind tunnel versions.